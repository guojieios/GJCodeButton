//
//  GJCodeButton.m
//  TimerButton
//
//  Created by 郭杰 on 2018/5/7.
//  Copyright © 2018年 JG. All rights reserved.
//

#import "GJCodeButton.h"

#define KTime   60 //设置重新发送的时间
@interface GJCodeButton(){
    //定时器
    NSTimer *_Timer;
}

@property (nonatomic,assign) NSInteger timerCount;


@end


@implementation GJCodeButton


-(void)setStartSecond:(int)startSecond {
    
    _startSecond = startSecond;
    
    _timerCount = _startSecond;
    
}




- (instancetype)initWithFrame:(CGRect)frame {
    
    if (self = [super initWithFrame:frame]) {
        
        _timerCount = KTime;
        
        [self setTitle:@"获取验证码" forState:UIControlStateNormal];
        [self.titleLabel setFont:[UIFont systemFontOfSize:14]];
        [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addTarget:self action:@selector(sentCodeBtnClick) forControlEvents:UIControlEventTouchUpInside];
        self.enabled = YES;
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 5;
        
//         刷新界面
        [self refreshButtonView];
        
        
    }
    
    return self;
}



- (void)sentCodeBtnClick {
    
    //获取验证码
    _downButtonBlock();
    
    
//     失效
    self.enabled = NO;
    
//     刷新界面
    [self refreshButtonView];
    [self setTitle:[NSString stringWithFormat:@"获取验证码(%zi)", _timerCount] forState:UIControlStateNormal];
    
    _Timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerFunction) userInfo:nil repeats:YES];
}


#pragma mark - 计时方法
- (void)timerFunction {
    [self setTitle:[NSString stringWithFormat:@"获取验证码(%zi)", _timerCount] forState:UIControlStateNormal];
    if (_timerCount == 0) {
        [self setTitle:@"重新获取" forState:UIControlStateNormal];
        self.enabled = YES;
        [self refreshButtonView];
        [_Timer invalidate];
        _Timer = nil;
        _timerCount = KTime;
    }else{
        _timerCount --;
    }
    
}





#pragma mark - 刷新button界面
- (void)refreshButtonView{
    
    [self setBackgroundImage:[self imageWithColor:[UIColor colorWithRed:1.000 green:0.310 blue:0.000 alpha:1.00] andSize:self.frame.size] forState:UIControlStateNormal];
    [self setBackgroundImage:[self imageWithColor:[UIColor lightGrayColor] andSize:self.frame.size] forState:UIControlStateDisabled];
}


- (UIImage *)imageWithColor:(UIColor *)color andSize:(CGSize)aSize{
    CGRect rect = CGRectMake(0.0f, 0.0f, aSize.width, aSize.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}



@end
