//
//  GJCodeButton.h
//  TimerButton
//
//  Created by 郭杰 on 2018/5/7.
//  Copyright © 2018年 JG. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef void(^ClickDownButtonBlock)();

@interface GJCodeButton : UIButton


//开始时间数
@property(nonatomic , assign) int startSecond;

@property(nonatomic , copy) ClickDownButtonBlock downButtonBlock; //点击按钮


@end
